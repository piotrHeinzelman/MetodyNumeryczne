

function [X] = aryx()

    X = (-1.5:0.1:1.5);

disp (X);
end