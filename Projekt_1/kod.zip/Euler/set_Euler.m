function set_Euler(num)
    global CFG
    config( 5, [   num,  0, 0 ]);  %     Euler mode: 0 - normal, 1 - extended
end