% "const" - funkcja stała
function y = Mj0(u)
    y=.8;
end
    