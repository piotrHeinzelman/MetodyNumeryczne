function setSection( sec )
global CFG
    config( 8, [   0,  sec, 0 ]);
end