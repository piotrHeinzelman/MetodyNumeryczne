function setUProst( Vmax )
    config( 6, [  1,  Vmax, 0 ]);
    UGen();
end