function setStepH( step )
global CFG
 config( 2, [   0,   step,   30   ]); %   h params
end