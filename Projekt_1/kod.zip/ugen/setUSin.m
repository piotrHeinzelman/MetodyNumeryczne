function setUsin( Vmax, f )
    config( 6, [   0,  Vmax, f ]);
    UGen();
end